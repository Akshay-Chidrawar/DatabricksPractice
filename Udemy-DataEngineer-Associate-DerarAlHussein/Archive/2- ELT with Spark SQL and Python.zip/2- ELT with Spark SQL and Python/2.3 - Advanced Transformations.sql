-- Databricks notebook source
-- MAGIC %run ../Includes/Copy-Datasets

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ## Parsing JSON Data

-- COMMAND ----------

CREATE OR REPLACE TABLE customers AS
SELECT * FROM JSON.`${dataset.bookstore}/customers-json`;

CREATE OR REPLACE TEMP VIEW parsed_customers AS
SELECT  customer_id, 
        from_json(profile
                  ,schema_of_json('{"first_name":"Thomas","last_name":"Lane","gender":"Male","address":{"street":"06 Boulevard Victor Hugo","city":"Paris","country":"France"}}')) AS profile_struct
FROM customers;

CREATE OR REPLACE TEMP VIEW customers_final AS
SELECT customer_id, profile_struct.*
FROM parsed_customers;

/*
"schema_of_json" --> derives schema details (DDL format) from nested JSON data provided.
"from_json" --> converts JSON string "profile" into "struct" data type with help of schema derived in step1.

sample nested record (json) can be fetched from below SQL:
SELECT profile 
FROM customers 
LIMIT 1
*/

DESCRIBE customers;
DESCRIBE parsed_customers;

SELECT * FROM customers; --nested data stored as plain string. 
SELECT * FROM parsed_customers; --nested data stored as struct data type.

SELECT customer_id, profile:*
FROM customers;

SELECT customer_id, profile:first_name, profile:address:country 
FROM customers;

SELECT customer_id, profile_struct.first_name, profile_struct.address.country
FROM parsed_customers;

SELECT * FROM customers_final;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Flatten full JSON data at once with Explode Function

-- COMMAND ----------

CREATE OR REPLACE TABLE orders AS
SELECT * FROM PARQUET.`${dataset.bookstore}/orders`;

CREATE OR REPLACE TABLE orders_exploded AS
SELECT customer_id, order_id, explode(books) AS book 
FROM orders;

SELECT * FROM orders; --"books" is an array of 'struct type' (possible due to parquet format).
SELECT * FROM orders_exploded; -- "explode" function will break the "books" array & thus each individual 'struct type' will have its own row. This might result in duplication of (order_id, customer_id). 

SELECT customer_id
,collect_set(order_id) AS orders_set -- array of distinct "orders" per "customer".
,collect_set(books.book_id) AS books_set_before_flatten -- array of (array of distinct "books" per "order") per "customer". this is 2 level nests.
,array_distinct(flatten(collect_set(books.book_id))) AS books_set_after_flatten --flatten the 2 level nest into single array. "array_distinct" will fetch distinct values of flattened array. 

/*
collect_set & array_distnct seem to perform same function, but differ in below aspects: 

collect_set:
- aggregation funciton, aggregates unique values.
- accepts a table column as input.
- returns new array of distinct values (unordered).

array_distnct:
- transformation function, removes duplicates. 
- accepts an array as input.
- returns transformed version of existing array by removing duplicates (maintains same order of elements).

 */

FROM orders
GROUP BY customer_id;

SELECT customer_id, explode(book_id) AS book 
FROM 
(
SELECT customer_id,books.book_id as book_id
FROM orders
);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ##SQL Operations
-- MAGIC 1. Joins
-- MAGIC 2. Union, Intersect, Except (or Minus)
-- MAGIC 3. Pivot reshape

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW vw_books 
USING CSV
OPTIONS (path="${dataset.bookstore}/books-csv",header = true, delimiter=";");

USE default;
CREATE OR REPLACE TABLE books AS
SElECT * FROM vw_books;

SElECT * FROM books;
SElECT * FROM orders_exploded;

CREATE OR REPLACE VIEW orders_enriched AS
SELECT *
FROM orders_exploded o
INNER JOIN books b ON o.book.book_id = b.book_id;

SELECT * FROM orders_enriched;

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW orders_updates
AS SELECT * FROM parquet.`${dataset.bookstore}/orders-new`;

SELECT * FROM orders 
UNION 
SELECT * FROM orders_updates;

SELECT * FROM orders 
INTERSECT 
SELECT * FROM orders_updates;

SELECT * FROM orders 
MINUS 
SELECT * FROM orders_updates;

-- COMMAND ----------

CREATE OR REPLACE TABLE transactions AS
SELECT * FROM 
(
SELECT customer_id,
      book.book_id AS book_id,
      book.quantity AS quantity
FROM  orders_enriched
)PIVOT 
(
sum(quantity) 
FOR book_id in 
(
'B01', 'B02', 'B03', 'B04', 'B05', 'B06','B07', 'B08', 'B09', 'B10', 'B11', 'B12'
)
);

SELECT * FROM transactions;